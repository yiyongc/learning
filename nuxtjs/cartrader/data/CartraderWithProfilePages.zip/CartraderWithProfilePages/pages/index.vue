<script setup>
useHead({
  title: "Cartrader",
});
</script>

<template>
  <div>
    <CarHero />
  </div>
</template>
  
