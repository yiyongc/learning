<script setup>
</script>

<template>
  <div>
    <CarCards />
  </div>
</template>
